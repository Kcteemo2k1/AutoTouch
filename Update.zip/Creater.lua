----------------------------------------------------------------
-- 🌐 IBestCloud Device Creater & Auto Injector (Fixed for Your Folder)
-- By Mr.L
----------------------------------------------------------------

local curl = require("cURL")

-- ⚙️ THÔNG SỐ CẤU HÌNH CỨNG
local jwt           = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."  -- JWT thật
local device_id     = "227ce1968e1b431a"
local device_name   = "KL1"
local device_boxname= "A1"

----------------------------------------------------------------
-- 📂 DÙNG rootDir() để xác định vị trí script hiện tại
----------------------------------------------------------------
local baseDir   = rootDir()
local fb_script = baseDir .. "/FacebookAuto.lua"
local tt_script = baseDir .. "/TikTokAuto.lua"

----------------------------------------------------------------
-- 🌍 GỌI API TẠO THIẾT BỊ
----------------------------------------------------------------
local api_url = string.format(
    "https://ibestcloud.com/api/v1/tool/action/get?device_id=%s&device_name=%s&device_boxname=%s&jwt=%s&action_type=remote_control&type=script",
    device_id, device_name, device_boxname, jwt
)

local function callAPI(url)
    local response = ""
    local c = curl.easy{
        url = url,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }
    local ok, err = pcall(function() c:perform() end)
    c:close()
    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end
    return response
end

----------------------------------------------------------------
-- ✏️ GHI ĐÈ CẤU HÌNH TRỰC TIẾP TRONG 2 SCRIPT
----------------------------------------------------------------
local function updateScript(path)
    local f = io.open(path, "r")
    if not f then
        toast("⚠️ Không tìm thấy file: " .. path)
        return false
    end
    local content = f:read("*a")
    f:close()

    -- Ghi đè các dòng cấu hình (bao phủ cả kiểu deviceID và device_id)
    content = content
        :gsub('local%s+jwt%s*=%s*".-"',          'local jwt = "' .. jwt .. '"')
        :gsub('local%s+deviceID%s*=%s*".-"',      'local deviceID = "' .. device_id .. '"')
        :gsub('local%s+device_id%s*=%s*".-"',     'local device_id = "' .. device_id .. '"')
        :gsub('local%s+device_name%s*=%s*".-"',   'local device_name = "' .. device_name .. '"')
        :gsub('local%s+device_boxname%s*=%s*".-"','local device_boxname = "' .. device_boxname .. '"')

    local fw = io.open(path, "w")
    fw:write(content)
    fw:close()

    toast("✅ Đã cập nhật thông số trong: " .. path)
    return true
end

----------------------------------------------------------------
-- 🚀 THỰC THI
----------------------------------------------------------------
toast("📡 Gọi API tạo thiết bị...")
local res = callAPI(api_url)
if not res then
    toast("❌ Không thể tạo thiết bị.")
    return
end

toast("✅ Thiết bị đã được tạo thành công, đang cập nhật 2 script...")
updateScript(fb_script)
updateScript(tt_script)

toast("🎉 Hoàn tất – JWT và Device Info đã ghi đè vào FacebookAuto.lua & TikTokAuto.lua")
log("📜 Server response:\n" .. res)
