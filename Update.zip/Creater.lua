----------------------------------------------------------------
-- 🌐 IBestCloud Device Creator – By Mr.L
----------------------------------------------------------------

local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
local device_id = "TB01"
local device_name = "KL1"
local device_boxname = "A1"

local apiURL = string.format(
    "https://ibestcloud.com/api/v1/tool/action/get?device_id=%s&device_name=%s&device_boxname=%s&jwt=%s&action_type=remote_control&type=script",
    device_id, device_name, device_boxname, jwt
)

----------------------------------------------------------------
-- ⚙️ CURL REQUEST
----------------------------------------------------------------
local function callAPI(url)
    local curl = require("cURL")
    local response = ""

    local c = curl.easy{
        url = url,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }

    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ CURL Error: " .. tostring(err))
        return nil
    end

    return response
end

----------------------------------------------------------------
-- 🧩 MAIN EXECUTION
----------------------------------------------------------------
toast("📡 Gọi API tạo thiết bị...")

local res = callAPI(apiURL)
if res then
    log("📩 Server response:\n" .. res)
    toast("✅ Thiết bị đã được tạo hoặc cập nhật!")
else
    toast("⚠️ Không nhận được phản hồi từ server")
end
