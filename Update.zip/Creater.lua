----------------------------------------------------------------
-- 🌐 IBestCloud / DRXCloudPhone Device Creater & Auto Injector v2.0
-- ✅ Auto register new device + inject config into scripts
-- 🔗 Uses api.drxcloudphone.com with action_type=remote_control
-- By Mr.L
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- ⚙️ HARD CONFIG
----------------------------------------------------------------
local jwt            = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTXJMIiwidXNlcl9pZCI6MywibGFzdF90aW1lX3B3IjowLCJpYXQiOjE3NjI3NTIxODN9.susWUV50UAO3aEparx_3sxWjAWWzV2gtaNs_ZxuVaBA"
local device_id      = "a3"
local device_name    = "KLKL2"
local device_boxname = "A1"

----------------------------------------------------------------
-- 📁 LOCAL PATH (AutoTouch rootDir)
----------------------------------------------------------------
local baseDir   = rootDir()
local fb_script = baseDir .. "/FacebookAuto.lua"
local tt_script = baseDir .. "/TikTokAuto.lua"

----------------------------------------------------------------
-- 🌍 REGISTER DEVICE VIA API
----------------------------------------------------------------
local api_url = string.format(
    "https://api.drxcloudphone.com/api/v1/tool/action/get?device_id=%s&device_name=%s&device_boxname=%s&jwt=%s&action_type=remote_control&type=script",
    device_id, device_name, device_boxname, jwt
)

local function callAPI(url)
    local response = ""
    local c = curl.easy{
        url = url,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        timeout = 20,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }
    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ API Error: " .. tostring(err))
        return nil
    end

    if response == "" then
        toast("⚠️ Empty response from API")
        return nil
    end
    return response
end

----------------------------------------------------------------
-- ✏️ INJECT CONFIG INTO TARGET SCRIPTS
----------------------------------------------------------------
local function updateScript(path)
    local f = io.open(path, "r")
    if not f then
        toast("⚠️ Không tìm thấy file: " .. path)
        return false
    end
    local content = f:read("*a")
    f:close()

    -- Replace all common patterns
    content = content
        :gsub('local%s+jwt%s*=%s*".-"',           'local jwt = "' .. jwt .. '"')
        :gsub('local%s+deviceID%s*=%s*".-"',       'local deviceID = "' .. device_id .. '"')
        :gsub('local%s+device_id%s*=%s*".-"',      'local device_id = "' .. device_id .. '"')
        :gsub('local%s+device_name%s*=%s*".-"',    'local device_name = "' .. device_name .. '"')
        :gsub('local%s+device_boxname%s*=%s*".-"', 'local device_boxname = "' .. device_boxname .. '"')

    local fw = io.open(path, "w")
    fw:write(content)
    fw:close()

    toast("✅ Injected info into: " .. path)
    return true
end

----------------------------------------------------------------
-- 🚀 MAIN EXECUTION
----------------------------------------------------------------
toast("📡 Đang gọi API tạo / đồng bộ thiết bị...")
local res = callAPI(api_url)
if not res then
    toast("❌ Không thể kết nối server.")
    return
end

log("📨 API response:\n" .. res)

if res:match('"code"%s*:%s*200') then
    toast("✅ Thiết bị đã được tạo / đồng bộ thành công!")
else
    toast("⚠️ Server trả lỗi, kiểm tra log.")
end

toast("🧩 Đang ghi đè thông số vào 2 script...")
updateScript(fb_script)
updateScript(tt_script)

toast("🎉 Hoàn tất – JWT và Device Info đã được cập nhật!")
log("📜 Done: Device [" .. device_id .. "] – Box [" .. device_boxname .. "] synced successfully.")
