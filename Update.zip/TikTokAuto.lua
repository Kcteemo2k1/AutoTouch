----------------------------------------------------------------
-- 🎬 TikTok AutoFlow v8.5p-FixLog5s-DeleteFlowIntegrated_v1.3-FULL
-- ✅ follow → like → share → comment → delete → download → upload
-- 🧠 Safe Delay / Auto Kill / Stable Log / DeleteFlow Integrated
-- By Mr.L
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- 🪪 CONFIGURATION
----------------------------------------------------------------
local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTXJMIiwidXNlcl9pZCI6MywibGFzdF90aW1lX3B3IjowLCJpYXQiOjE3NjI3NTIxODN9.susWUV50UAO3aEparx_3sxWjAWWzV2gtaNs_ZxuVaBA"
local deviceID = "227ce1968e1b431a"
local hostName = "https://api.drxcloudphone.com"
local apiGet = hostName .. "/api/v1/tool/action/get?action_type=tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID

local shortcutSave = "AutoSaveVideo"
local shortcutDelete = "DeletePhotos"
local imgPath = rootDir() .. "/img/"
local fixedURL = "http://file.fms-router.com:9999/data/tiktok2/2.mp4"

----------------------------------------------------------------
-- ⚙️ UTILITIES
----------------------------------------------------------------
local function sleep4() usleep(5000000) end
local function sleep3() usleep(3000000) end
local function delayKill() usleep(5000000) end
local function delayLog() usleep(5000000) end

local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(85000)
    touchUp(1, x, y)
    usleep(delay or 1000000)
end

local function findImgRetry(name, thr, retries)
    local threshold = thr or 0.4
    local fullPath = imgPath .. name
    retries = retries or 3
    for i = 1, retries do
        toast("🔍 Tìm ảnh: " .. name .. " (lần " .. i .. ")")
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(1000000)
    end
    toast("❌ Không thấy " .. name .. " sau " .. retries .. " lần")
    return nil, nil
end

local function getBasePlus()
    local x, y = findImgRetry("whiteplus.png", 0.4, 3)
    if x and y then return x, y end
    toast("⚠️ Fallback whiteplus → (381,1283)")
    return 381, 1283
end

local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then 
            openURL(url)
        else
            require "objc"
            local NSURL = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 SERVER LOG (PUT by _id)
----------------------------------------------------------------
local function sendLog(actionId, logText, statusCode)
    if not actionId then
        toast("⚠️ Thiếu _id, bỏ qua log")
        return
    end

    local apiLog = string.format("%s/api/v1/tool/action/%s?jwt=%s", hostName, actionId, jwt)
    local body = string.format('{"log":"%s","status":%d}', logText, statusCode)
    local resp = ""

    local ok, err = pcall(function()
        local c = curl.easy{
            url = apiLog,
            postfields = body,
            customrequest = "PUT",
            httpheader = {"Content-Type: application/json"},
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            timeout = 15,
            writefunction = function(s) resp = resp .. s return #s end
        }
        c:perform()
        c:close()
    end)

    if not ok then
        toast("❌ Lỗi gửi log: " .. tostring(err))
    else
        local code = resp:match('"code"%s*:%s*(%d+)') or "???"
        toast(string.format("📤 PUT Log [%d] – %s (code:%s)", statusCode, logText, code))
    end
end

----------------------------------------------------------------
-- 🛰️ GET ACTION DATA
----------------------------------------------------------------
local function getAPIResponse()
    local response = ""
    local c = curl.easy{
        url = apiGet,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(s) response = response .. s return #s end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

----------------------------------------------------------------
-- 🧠 PARSE RESPONSE
----------------------------------------------------------------
local ORDER = {"follow","like","share","comment","deletevideo","downloadvideo","postvideo","uppost"}

local function sortActions(actions)
    table.sort(actions, function(a,b)
        local ia, ib = 999, 999
        for i,v in ipairs(ORDER) do
            if v == a then ia = i end
            if v == b then ib = i end
        end
        return ia < ib
    end)
    return actions
end

local function extractOptions(resp)
    if not resp or resp == "" then return nil end
    local id = resp:match('"_id"%s*:%s*"(.-)"')
    if not id then toast("⚠️ Không tìm thấy _id trong phản hồi") return nil end

    local actions, linkAcc, linkPost, commentContent = {}, {}, {}, {}
    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do table.insert(actions, v:lower()) end
    end
    actions = sortActions(actions)
    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do for v in b:gmatch('"(.-)"') do table.insert(linkAcc,v) end end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do for v in c:gmatch('"(.-)"') do table.insert(linkPost,v) end end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do for v in d:gmatch('"(.-)"') do table.insert(commentContent,v) end end
    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5

    return {
        _id = id,
        actions = actions,
        linkAcc = linkAcc,
        linkPost = linkPost,
        commentContent = commentContent,
        delay = math.max(delay,5)
    }
end

----------------------------------------------------------------
-- 🎞️ ACTION FUNCTIONS
----------------------------------------------------------------

function autoUploadVideo()
    toast("🚀 Upload Video – Restart TikTok...")
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    openURLSafe("snssdk1233://main")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px, py)
    toast("📸 Nhấn WhitePlus")
    sleep4()

    toast("📂 Mở Library (trái + phải)")
    touchDown(5, 91.35, 1270.06)
    usleep(249928.12)
    touchUp(5, 91.35, 1270.06)
    usleep(635051.00)
    tap(601, 1120)
    usleep(6000000)

    tap(351, 433)
    toast("🎞️ Chọn video đầu tiên")
    usleep(6000000)

    local nextX, nextY = findImgRetry("nextbutton.png", 0.4, 3)
    if nextX then
        tap(nextX, nextY)
        usleep(1500000)
        tap(nextX, nextY)
    else
        tap(570,1283)
        usleep(1500000)
        tap(554,1286)
    end
    usleep(6000000)

    local postX, postY = findImgRetry("post.png", 0.4, 3)
    if postX then tap(postX, postY) else tap(554,1286) end
    toast("✅ Đăng video hoàn tất")
    sleep4()
end

function autoComment(opt)
    toast("💬 Comment video...")
    if not (opt and opt.linkPost and #opt.linkPost > 0) then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px + 320, py - 530)
    usleep(4000000)
    tap(px, py)
    usleep(3000000)

    local cmt = (#(opt.commentContent or {}) > 0 and opt.commentContent[1]) or "Tuyệt vời quá!"
    inputText(cmt)
    usleep(2000000)
    tap(672, 752)
    sleep4()
    toast("✅ Comment hoàn tất")

    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()
end

function autoLike(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local px, py = getBasePlus()
    tap(px + 317, py - 660)
    sleep4()
end

function autoShare(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local px, py = getBasePlus()
    tap(px + 320, py - 257)
    sleep4()

    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()
end

function autoFollow(opt)
    if not opt.linkAcc or #opt.linkAcc == 0 then return end
    local username = opt.linkAcc[1]:match("@([%w%._%-]+)")
    if not username then return end
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    openURLSafe("snssdk1233://user/@" .. username)
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local fX, fY = findImgRetry("follow_button.png", 0.4, 3)
    if fX then tap(fX, fY) else tap(550, 250) end
    sleep4()
end

----------------------------------------------------------------
-- 🧩 DELETEFLOW INTEGRATED
----------------------------------------------------------------
local function handleDeleteConfirm()
    toast("🔍 Kiểm tra hộp thoại xác nhận...")

    local dx, dy = findImgRetry("delete1.png", 0.4, 2)
    if dx and dy then tap(dx, dy) toast("✅ Nhấn delete1.png") return end

    local ax, ay = findImgRetry("deleteall.png", 0.4, 2)
    if ax and ay then tap(ax, ay) toast("✅ Nhấn deleteall.png") return end

    local okx, oky = findImgRetry("ok.png", 0.4, 2)
    if okx and oky then tap(okx, oky) toast("⚠️ Nhấn OK") return end

    toast("🚫 Không phát hiện nút xác nhận – bỏ qua thao tác.")
end

function deleteVideo()
    toast("🧹 Bắt đầu DeleteFlow tích hợp...")
    appKill("com.apple.shortcuts")
    sleep3()

    local shortcuts = {"DeleteVideo", "DeletePhoto", "AutoSaveVideo"}
    for _, name in ipairs(shortcuts) do
        local cmd = "shortcuts://run-shortcut?name=" .. name
        toast("🚀 Chạy Shortcut: " .. name)
        openURLSafe(cmd)
        sleep4()
        handleDeleteConfirm()
        sleep3()
    end

    toast("🏁 DeleteFlow hoàn tất.")
    sleep4()
end

function downloadVideo()
    local encoded = fixedURL:gsub("([^%w])", function(c) return string.format("%%%02X", string.byte(c)) end)
    local cmd = string.format('shortcuts://run-shortcut?name=%s&inputText=%s', shortcutSave, encoded)
    openURLSafe(cmd)
    sleep4()
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow v8.5p-FixLog5s-DeleteFlowIntegrated_v1.3 Started...")

delayKill()
appKill("com.ss.iphone.ugc.Ame")
sleep4()

local actionMap = {
    deletevideo = deleteVideo,
    downloadvideo = downloadVideo,
    postvideo = autoUploadVideo,
    uppost = autoUploadVideo,
    like = autoLike,
    share = autoShare,
    follow = autoFollow,
    comment = autoComment
}

while true do
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    local resp = getAPIResponse()
    local opt = extractOptions(resp)

    if not opt or not opt._id then
        toast("⚠️ API lỗi / không có _id hợp lệ")
        sleep4()
    else
        local actionId = opt._id
        sendLog(actionId, "Start drx tiktok", 1)
        toast("🆔 _id: " .. tostring(actionId))

        if #opt.actions > 0 then
            for _, act in ipairs(opt.actions) do
                local fn = actionMap[act]
                if fn then
                    toast("▶️ Thực hiện: " .. act)
                    pcall(function() fn(opt) end)
                else
                    toast("⚙️ Bỏ qua hành động: " .. act)
                end
                usleep((opt.delay or 5) * 1000000)
            end
            delayLog()
            sendLog(actionId, "End drx tiktok", 2)
            toast("📨 Log End đã gửi xong.")
        else
            sendLog(actionId, "Fail drx tiktok (no actions)", 3)
        end
    end
    sleep4()
end

toast("🛑 Dừng vòng lặp – By Mr.L")
