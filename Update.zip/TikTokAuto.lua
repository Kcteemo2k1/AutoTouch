----------------------------------------------------------------
-- 🎬 TikTok AutoLoop – Full Integration (Follow + Interact + Up Story + Up Post)
-- ✅ Version v7.7 – WhitePlus Core Comment – Accuracy 0.4 + Delay ≥ 4s
-- By Mr.L
----------------------------------------------------------------

local jwt = "YOUR_JWT_TOKEN_HERE"
local deviceID = "YOUR_DEVICE_ID_HERE"
local apiURL = "https://ibestcloud.com/api/v1/tool/action/get?action_type=Tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID
local imgPath = rootDir() .. "/img/"

----------------------------------------------------------------
-- ⚙️ TIỆN ÍCH
----------------------------------------------------------------
local function sleep4() usleep(4000000) end
local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(90000)
    touchUp(1, x, y)
    usleep(delay or 4000000)
end

----------------------------------------------------------------
-- 🔍 FIND IMAGE (Retry 3 lần + Toast chi tiết + Kiểm tra tọa độ)
----------------------------------------------------------------
local function findImg(name, thr)
    local threshold = thr or 0.4
    local fullPath = imgPath .. name
    local x, y = nil, nil
    for i = 1, 3 do
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            x, y = r[1][1], r[1][2]
            if x > 10 and y > 10 and x < 1080 and y < 2400 then
                toast("✅ Tìm thấy " .. name .. " (Lần " .. i .. ") tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
                return x, y
            end
        else
            toast("🔎 Chưa thấy " .. name .. " (Thử lần " .. i .. ")")
        end
        usleep(1000000)
    end
    toast("❌ Không thấy " .. name)
    return nil, nil
end

----------------------------------------------------------------
-- 🌐 MỞ URL AN TOÀN
----------------------------------------------------------------
local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then
            openURL(url)
        else
            require "objc"
            local NSURL, UIApplication = objc.NSURL, objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 MỞ TIKTOK PROFILE (HOME + URL)
----------------------------------------------------------------
local function openTikTokProfile(profileURL)
    local url = profileURL or "https://www.tiktok.com/profile"
    toast("🏠 Trở về Home...")
    keyDown(KEY_TYPE.HOME_BUTTON); usleep(200000); keyUp(KEY_TYPE.HOME_BUTTON)
    sleep4()
    toast("🌐 Mở TikTok Profile...")
    openURLSafe(url)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 GỌI API
----------------------------------------------------------------
local function getAPIResponse()
    local curl = require("cURL")
    local response = ""
    local c = curl.easy{
        url = apiURL,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }
    local ok, err = pcall(function() c:perform() end)
    c:close()
    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end
    return response
end

----------------------------------------------------------------
-- 🧩 TRÍCH DỮ LIỆU
----------------------------------------------------------------
local function extractOptions(resp)
    local actions, linkAcc, linkPost, commentList, myProfile = {}, {}, {}, {}, {}
    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do for v in a:gmatch('"(.-)"') do table.insert(actions, v) end end
    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do for v in b:gmatch('"(.-)"') do table.insert(linkAcc, v) end end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do for v in c:gmatch('"(.-)"') do table.insert(linkPost, v) end end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do for v in d:gmatch('"(.-)"') do table.insert(commentList, v) end end
    for e in resp:gmatch('"myProfile"%s*:%s*%[(.-)%]') do for v in e:gmatch('"(.-)"') do table.insert(myProfile, v) end end
    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    return { actions=actions, linkAcc=linkAcc, linkPost=linkPost, commentList=commentList, myProfile=myProfile, delay=math.max(delay*1000000,4000000) }
end

local function hasAction(opt, act)
    for _, a in ipairs(opt.actions or {}) do if a == act then return true end end
    return false
end

local function randomComment(opt)
    local list = opt.commentList or {}
    if #list == 0 then return nil end
    return list[math.random(1, #list)]
end

----------------------------------------------------------------
-- 🔘 AUTO FOLLOW
----------------------------------------------------------------
local function followAccounts(opt)
    toast("🚀 AutoFollow...")
    for _, acc in ipairs(opt.linkAcc or {}) do
        if acc ~= "" then
            local username = acc:match("@([%w%._%-]+)")
            if username then
                local deep = "snssdk1233://user/@" .. username
                toast("🔗 Mở @" .. username)
                openURLSafe(deep)
                appActivate("com.ss.iphone.ugc.Ame")
                sleep4()

                local fX, fY = findImg("follow_button.png", 0.4)
                if fX and fY then
                    tap(fX, fY)
                    toast("✅ Follow @" .. username)
                else
                    toast("⚠️ Không thấy follow_button.png – bỏ qua @" .. username)
                end
                sleep4()
            end
        end
    end
end

----------------------------------------------------------------
-- 💬 AUTO INTERACT POST (WhitePlus Core v7.7)
----------------------------------------------------------------
local function interactPosts(opt)
    toast("🚀 AutoInteract (WhitePlus Core)...")
    keyDown(KEY_TYPE.HOME_BUTTON); keyUp(KEY_TYPE.HOME_BUTTON); sleep4()

    for _, post in ipairs(opt.linkPost or {}) do
        local awemeID = post:match("/video/(%d+)")
        local deep = awemeID and ("snssdk1233://aweme/detail/" .. awemeID) or post
        openURLSafe(deep)
        appActivate("com.ss.iphone.ugc.Ame")
        sleep4()

        local px, py = findImg("whiteplus.png", 0.4)
        if px and py then
            local function tapOffset(ref, dx, dy)
                local x, y = px + dx, py + dy
                touchDown(1, x, y); usleep(90000); touchUp(1, x, y)
                usleep(4000000)
                toast("👆 " .. ref .. " tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            end

            local OFF = {
                like = {317, -660}, save = {324, -390},
                share = {320, -257}, repost = {-287, -260},
                commentInput = {-143, -6}, sendBtn = {290, -525}
            }

            tapOffset("Like", OFF.like[1], OFF.like[2])
            tapOffset("Save", OFF.save[1], OFF.save[2])
            tapOffset("Share", OFF.share[1], OFF.share[2])
            tapOffset("Repost", OFF.repost[1], OFF.repost[2])

            local cX, cY = findImg("commentbutton.png", 0.4)
            if cX and cY then
                tap(cX, cY)
                sleep4()

                tapOffset("CommentInput", OFF.commentInput[1], OFF.commentInput[2])
                sleep4()
                usleep(2000000)

                local cmt = randomComment(opt) or "Video tuyệt vời quá "
                toast("⌨️ Đang nhập: " .. cmt)
                inputText(cmt)
                usleep(1500000)

                tapOffset("SendButton", OFF.sendBtn[1], OFF.sendBtn[2])
                toast("✅ Đã gửi comment: " .. cmt)
            else
                toast("❌ Không tìm thấy commentbutton.png – bỏ qua comment")
            end
        else
            toast("❌ Không tìm thấy whiteplus.png – bỏ qua bài này")
        end
        sleep4()
    end
end

----------------------------------------------------------------
-- 📤 AUTO UP STORY
----------------------------------------------------------------
local function autoUpStory(opt)
    toast("🚀 AutoUpStory...")
    openTikTokProfile()
    sleep4()

    local editX, editY = findImg("editbutton.png", 0.4)
    if not editX or not editY then toast("⚠️ Không thấy EditButton"); return end

    tap(editX - 83.0, editY - 83.0); sleep4()
    local allX, allY = findImg("allbutton.png", 0.4)
    if not allX then toast("⚠️ Không thấy AllButton"); return end

    tap(allX, allY + 450); sleep4()
    local sX, sY = findImg("story.png", 0.4)
    if sX then
        tap(sX, sY); toast("✅ Story uploaded!")
    else
        toast("⚠️ Không thấy story.png")
    end
    sleep4()
end

----------------------------------------------------------------
-- 📤 AUTO UP POST
----------------------------------------------------------------
local function autoUploadVideo(opt)
    toast("🚀 AutoUploadVideo...")
    keyDown(KEY_TYPE.HOME_BUTTON); keyUp(KEY_TYPE.HOME_BUTTON); sleep4()
    openURLSafe("snssdk1233://feed?refer=web")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local x, y = findImg("whiteplus.png", 0.4)
    if not x then toast("⚠️ Không tìm thấy whiteplus.png"); return end
    tap(x, y); sleep4()
    tap(x - 320, y); sleep4()

    local allX, allY = findImg("whiteallbutton.png", 0.4)
    if allX then tap(allX, allY + 100); sleep4(); tap(allX, allY + 200); sleep4() end

    local nextX, nextY = findImg("nextbutton.png", 0.4)
    if nextX then tap(nextX, nextY); sleep4(); tap(nextX, nextY); sleep4() end

    local postX, postY = findImg("post.png", 0.4)
    if postX then tap(postX, postY); toast("✅ Video uploaded!") else toast("⚠️ Không thấy post.png") end
    sleep4()
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP
----------------------------------------------------------------
toast("🚀 TikTok AutoLoop v7.7 – Bắt đầu hoạt động...")
math.randomseed(os.time())

while true do
    toast("📡 Gọi API lấy tác vụ...")
    local resp = getAPIResponse()
    if resp then
        local opt = extractOptions(resp)
        if opt and #opt.actions > 0 then
            if hasAction(opt, "follow") then followAccounts(opt) end
            if hasAction(opt, "like") or hasAction(opt, "share") or hasAction(opt, "comment") then interactPosts(opt) end
            if hasAction(opt, "upstory") then autoUpStory(opt) end
            if hasAction(opt, "uppost") then autoUploadVideo(opt) end
        else
            toast("⏳ Không có tác vụ – nghỉ 5s")
            sleep4()
        end
    else
        toast("⚠️ API lỗi – nghỉ 10s rồi thử lại")
        usleep(10000000)
    end
    sleep4()
end
