----------------------------------------------------------------
-- 🎬 TikTok AutoFlow v8.3k – Full Stable Final
-- ✅ Delete → Download → Upload → Like / Comment / Share / Follow
-- 🧠 API Log Auto / Kill app per loop / Safe fallback
-- By Mr.L
----------------------------------------------------------------

local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTmd1eWVuRHV5TGFtIiwidXNlcl9pZCI6OTAsImxhc3RfdGltZV9wdyI6MCwiaWF0IjoxNzYxNTE0MTMxfQ.TXOaXjnC__Iv3qIewzryrh_g92NlcR0YjVX0lpDTEek"
local deviceID = "227ce1968e1b431a"
local hostName = "https://ibestcloud.com"
local apiGet = hostName .. "/api/v1/tool/action/get?action_type=Tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID

local shortcutSave = "AutoSaveVideo"
local shortcutDelete = "Delete Photos"
local fixedURL = "http://file.fms-router.com:9999/data/tiktok2/2.mp4"
local imgPath = rootDir() .. "/img/"

local curl = require("cURL")

----------------------------------------------------------------
-- 🧩 UTILITIES
----------------------------------------------------------------
local function sleep4() usleep(5000000) end
local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(85000)
    touchUp(1, x, y)
    usleep(delay or 1000000)
end

local function findImgRetry(name, thr, retries)
    local threshold = thr or 0.4
    local fullPath = imgPath .. name
    retries = retries or 3
    for i = 1, retries do
        toast("🔍 Tìm ảnh: " .. name .. " (lần " .. i .. ")")
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(1000000)
    end
    toast("❌ Không thấy " .. name .. " sau " .. retries .. " lần")
    return nil, nil
end

local function getBasePlus()
    local x, y = findImgRetry("whiteplus.png", 0.4, 3)
    if x and y then return x, y end
    toast("⚠️ Fallback whiteplus → (381,1283)")
    return 381, 1283
end

local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then openURL(url)
        else
            require "objc"
            local NSURL = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 API LOG
----------------------------------------------------------------
local function sendLog(actionId, logText, statusCode)
    if not actionId then return end
    local apiLog = string.format("%s/api/v1/tool/action/%s?jwt=%s", hostName, actionId, jwt)
    local body = string.format('{"log": "%s", "status": %d}', logText, statusCode)

    local ok, res = pcall(function()
        local resp = ""
        local c = curl.easy{
            url = apiLog,
            postfields = body,
            customrequest = "PUT",
            httpheader = {"Content-Type: application/json"},
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            writefunction = function(str) resp = resp .. str return #str end
        }
        c:perform()
        c:close()
        return resp
    end)
    if ok then toast("📤 Gửi log [" .. statusCode .. "] – " .. logText)
    else toast("❌ Lỗi log: " .. tostring(res)) end
end

local function getAPIResponse()
    local response = ""
    local c = curl.easy{
        url = apiGet,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str) response = response .. str return #str end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

local function extractOptions(resp)
    if not resp or resp == "" then return nil end
    local taskId = resp:match('"task_id"%s*:%s*(%d+)') or resp:match('"_id"%s*:%s*"(.-)"')
    local actions, linkAcc, linkPost, commentContent = {}, {}, {}, {}
    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do for v in a:gmatch('"(.-)"') do table.insert(actions, v:lower()) end end
    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do for v in b:gmatch('"(.-)"') do table.insert(linkAcc, v) end end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do for v in c:gmatch('"(.-)"') do table.insert(linkPost, v) end end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do for v in d:gmatch('"(.-)"') do table.insert(commentContent, v) end end
    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    return {task_id = taskId, actions = actions, linkAcc = linkAcc, linkPost = linkPost, commentContent = commentContent, delay = math.max(delay,5)}
end

----------------------------------------------------------------
-- 📤 UPLOAD VIDEO (WhitePlus Core Stable)
----------------------------------------------------------------
function autoUploadVideo()
    toast("🚀 Upload Video – Restart TikTok...")
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    openURLSafe("snssdk1233://main")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px, py)
    toast("📸 Nhấn WhitePlus")
    sleep4()

    tap(601, 1120)
    toast("📂 Mở Library")
    usleep(6000000)

    tap(351, 433)
    toast("🎞️ Chọn video đầu tiên")
    usleep(6000000)

    local nextX, nextY = findImgRetry("nextbutton.png", 0.4, 3)
    if nextX then
        toast("➡️ Nhấn Next 2 lần")
        tap(nextX, nextY)
        usleep(1500000)
        tap(nextX, nextY)
    else
        toast("⚠️ Fallback tap next (570,1283)+(554,1286)")
        tap(570,1283)
        usleep(1500000)
        tap(554,1286)
    end
    usleep(6000000)

    local postX, postY = findImgRetry("post.png", 0.4, 3)
    if postX then
        tap(postX, postY)
        toast("✅ Đăng video thành công")
    else
        toast("⚠️ Fallback tap post (554,1286)")
        tap(554,1286)
    end
    sleep4()
end

----------------------------------------------------------------
-- 💬 COMMENT VIDEO (WhitePlus Core)
----------------------------------------------------------------
function autoComment(opt)
    toast("💬 Comment video...")
    if not (opt and opt.linkPost and #opt.linkPost > 0) then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    usleep(7000000)

    local px, py = getBasePlus()
    local commentBtnX, commentBtnY = px + 320, py - 530
    tap(commentBtnX, commentBtnY)
    usleep(4000000)

    tap(px, py)
    usleep(3000000)

    local cmt = (#(opt.commentContent or {}) > 0 and opt.commentContent[1]) or "Tuyệt vời quá!"
    inputText(cmt)
    usleep(2000000)

    tap(672, 752)
    usleep(4000000)

    toast("✅ Comment hoàn tất")
    sleep4()
end

----------------------------------------------------------------
-- ❤️ LIKE / 🔁 SHARE / ➕ FOLLOW
----------------------------------------------------------------
function autoLike(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    local px, py = getBasePlus()
    tap(px + 317, py - 660)
    sleep4()
end

function autoShare(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    local px, py = getBasePlus()
    tap(px + 320, py - 257)
    sleep4()
end

function autoFollow(opt)
    if not opt.linkAcc or #opt.linkAcc == 0 then return end
    local username = opt.linkAcc[1]:match("@([%w%._%-]+)")
    if not username then return end
    appKill("com.ss.iphone.ugc.Ame")
    usleep(2000000)
    openURLSafe("snssdk1233://user/@" .. username)
    appActivate("com.ss.iphone.ugc.Ame")
    usleep(5000000)
    local fX, fY = findImgRetry("follow_button.png", 0.4, 3)
    if fX then tap(fX, fY) else tap(550, 250) end
    sleep4()
end

----------------------------------------------------------------
-- 🗑️ DELETE + 📥 DOWNLOAD
----------------------------------------------------------------
function deleteVideo()
    local cmd = 'shortcuts://run-shortcut?name=' .. shortcutDelete
    if type(appOpenURL) == "function" then appOpenURL(cmd) else openURL(cmd) end
    sleep4()
end

function downloadVideo()
    local encoded = fixedURL:gsub("([^%w])", function(c) return string.format("%%%02X", string.byte(c)) end)
    local cmd = string.format('shortcuts://run-shortcut?name=%s&inputText=%s', shortcutSave, encoded)
    if type(appOpenURL) == "function" then appOpenURL(cmd) else openURL(cmd) end
    sleep4()
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP (Fixed no-goto)
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow v8.3k – Stable Started...")

local actionMap = {
    deletevideo = deleteVideo,
    downloadvideo = downloadVideo,
    postvideo = autoUploadVideo,
    uppost = autoUploadVideo,
    like = autoLike,
    comment = autoComment,
    share = autoShare,
    follow = autoFollow
}

while true do
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    local resp = getAPIResponse()
    local opt = extractOptions(resp)

    if not opt or not opt.task_id then
        toast("⚠️ API lỗi / không có task_id")
        sleep4()
    else
        local actionId = opt.task_id
        sendLog(actionId, "Start drx tiktok", 1)

        if #opt.actions > 0 then
            for _, act in ipairs(opt.actions) do
                local fn = actionMap[act]
                if fn then
                    toast("▶️ Thực hiện: " .. act)
                    pcall(function() fn(opt) end)
                else
                    toast("⚙️ Bỏ qua hành động: " .. act)
                end
                usleep((opt.delay or 5) * 1000000)
            end
            sendLog(actionId, "End drx tiktok", 2)
        else
            sendLog(actionId, "Fail drx tiktok (no actions)", 3)
        end
    end

    sleep4()
end

toast("🛑 Dừng vòng lặp – By Mr.L")
