----------------------------------------------------------------
-- 🎬 TikTok AutoLoop – Full Integration (Follow + Interact + AutoPostLatest)
-- ✅ Version chuẩn – By Mr.L
----------------------------------------------------------------

local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTmd1eWVuRHV5TGFtIiwidXNlcl9pZCI6OTAsImxhc3RfdGltZV9wdyI6MCwiaWF0IjoxNzYxNTE0MTMxfQ.TXOaXjnC__Iv3qIewzryrh_g92NlcR0YjVX0lpDTEek"
local deviceID = "227ce1968e1b431a"
local apiURL = "https://ibestcloud.com/api/v1/tool/action/get?action_type=Tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID
local imgPath = rootDir() .. "/img/"

----------------------------------------------------------------
-- ⚙️ TIỆN ÍCH
----------------------------------------------------------------
local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(80000)
    touchUp(1, x, y)
    usleep(delay or 500000)
end

local function findImg(name, thr)
    local r = findImage(imgPath .. name, 1, thr or 0.5, nil, false, 2)
    if r and #r > 0 then return r[1][1], r[1][2] end
    return nil, nil
end

local function waitAndTap(img, msg, thr)
    local x, y = findImg(img, thr or 0.4)
    if x and y then
        tap(x, y)
        if msg then toast(msg) end
        usleep(8000000)
        return true
    else
        toast("❌ Không tìm thấy " .. img)
        return false
    end
end

----------------------------------------------------------------
-- 🌐 MỞ TIKTOK PROFILE (HOME + URL)
----------------------------------------------------------------
local function openTikTokProfile(profileURL)
    local url = profileURL or "https://www.tiktok.com/profile"

    toast("🏠 Đang trở về màn hình chính (Home Screen)...")
    keyDown(KEY_TYPE.HOME_BUTTON)
    usleep(180000)
    keyUp(KEY_TYPE.HOME_BUTTON)
    usleep(2000000)

    toast("🌐 Chuẩn bị mở TikTok Profile qua URL...")

    if type(openURL) == "function" then
        openURL(url)
    elseif type(appOpenURL) == "function" then
        appOpenURL(url)
    else
        toast("⚠️ Không tìm thấy hàm mở URL!")
        return
    end

    usleep(6000000)
    toast("✅ Đã gửi lệnh mở TikTok Profile thành công!")
end

----------------------------------------------------------------
-- 🌐 GỌI API
----------------------------------------------------------------
local function getAPIResponse()
    local curl = require("cURL")
    local response = ""
    local c = curl.easy{
        url = apiURL,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }
    local ok, err = pcall(function() c:perform() end)
    c:close()
    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end
    return response
end

----------------------------------------------------------------
-- 🧩 TRÍCH DỮ LIỆU TRẢ VỀ
----------------------------------------------------------------
local function extractOptions(resp)
    local actions, linkAcc, linkPost, commentList, myProfile = {}, {}, {}, {}, {}

    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do table.insert(actions, v) end
    end
    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do
        for v in b:gmatch('"(.-)"') do table.insert(linkAcc, v) end
    end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do
        for v in c:gmatch('"(.-)"') do table.insert(linkPost, v) end
    end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do table.insert(commentList, v) end
    end
    for e in resp:gmatch('"myProfile"%s*:%s*%[(.-)%]') do
        for v in e:gmatch('"(.-)"') do table.insert(myProfile, v) end
    end

    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    return {
        actions = actions,
        linkAcc = linkAcc,
        linkPost = linkPost,
        commentList = commentList,
        myProfile = myProfile,
        delay = delay * 1000000
    }
end

local function hasAction(opt, act)
    for _, a in ipairs(opt.actions or {}) do
        if a == act then return true end
    end
    return false
end

local function randomComment(opt)
    local list = opt.commentList or {}
    if #list == 0 then return nil end
    return list[math.random(1, #list)]
end

----------------------------------------------------------------
-- 🔘 AUTO FOLLOW
----------------------------------------------------------------
local function followAccounts(opt)
    toast("🚀 Bắt đầu AutoFollow...")
    for i, acc in ipairs(opt.linkAcc or {}) do
        if acc ~= "" then
            local username = acc:match("@([%w%._%-]+)")
            if username then
                local link = "snssdk1233://user/@" .. username
                toast("🔗 Mở @" .. username)
                appOpenURL(link)
                usleep(6000000)

                local fX, fY = findImg("follow_button.png", 0.6)
                if fX and fY then
                    tap(fX, fY)
                    toast("✅ Đã nhấn Follow")
                    usleep(3000000)
                else
                    toast("⚠️ Không thấy nút Follow")
                end
            end
        end
    end
end

----------------------------------------------------------------
-- 💬 AUTO INTERACT POST
----------------------------------------------------------------
local function interactPosts(opt)
    keyDown(KEY_TYPE.HOME_BUTTON)
    usleep(2000000)
    keyUp(KEY_TYPE.HOME_BUTTON)
    usleep(2000000)

    for _, post in ipairs(opt.linkPost or {}) do
        local awemeID = post:match("/video/(%d+)")
        local deep = awemeID and ("snssdk1233://aweme/detail/" .. awemeID) or post
        toast("🎬 Mở bài: " .. post)
        appOpenURL(deep)
        usleep(7000000)
        appActivate("com.ss.iphone.ugc.Ame")

        -- Like, share, comment (theo toạ độ)
        touchDown(4, 688.71, 551.26); usleep(83259.46); touchUp(4, 688.71, 551.26); usleep(1534928.58);
        touchDown(3, 690.77, 949.35); usleep(83393.79); touchUp(3, 690.77, 949.35); usleep(1832034.67);
        touchDown(6, 108.79, 1006.36); usleep(101348.17); touchUp(6, 108.79, 1006.36); usleep(4482539.00);
        touchDown(1, 684.61, 684.63); usleep(67895.96); touchUp(1, 684.61, 684.63); usleep(1848500.00);
        touchDown(2, 355.13, 1275.15); usleep(101478.38); touchUp(2, 355.13, 1275.15);

        local cmt = randomComment(opt)
        if cmt then
            usleep(1000000)
            inputText(cmt)
            usleep(1000000)
            tap(671.26, 779.32)
            toast("💬 Comment: " .. cmt)
        else
            toast("⚠️ Không có comment trong danh sách")
        end
        usleep(opt.delay or 5000000)
    end
end

----------------------------------------------------------------
-- 📤 AUTO POST LATEST (EDIT → PLUS → ALL → STORY)
----------------------------------------------------------------
local function autoPostLatest(opt)
    toast("🚀 Bắt đầu AutoPostLatest...")

    openTikTokProfile()
    usleep(8000000)

    toast("🔍 Tìm nút EditButton...")
    local editX, editY = findImg("editbutton.png", 0.5)
    if not editX or not editY then
        toast("⚠️ Không tìm thấy EditButton – Dừng AutoPostLatest.")
        return
    end

    toast(string.format("✅ EditButton tại (%.2f, %.2f)", editX, editY))
    local plusX = editX - 83.0
    local plusY = editY - 83.0
    touchDown(6, plusX, plusY)
    usleep(95000)
    touchUp(6, plusX, plusY)
    toast("➕ Đã nhấn PlusButton")

    usleep(math.random(1000000, 2000000))

    toast("🔍 Tìm AllButton...")
    local allX, allY = findImg("allbutton.png", 0.5)
    if not allX or not allY then
        toast("⚠️ Không tìm thấy AllButton – Dừng lại.")
        return
    end

    toast(string.format("✅ AllButton tại (%.2f, %.2f)", allX, allY))
    local photoX, photoY = allX, allY + 450
    tap(photoX, photoY)
    usleep(1500000)

    usleep(math.random(1000000, 2000000))

    toast("📸 Tìm nút Story...")
    local sX, sY = findImg("story.png", 0.5)
    if sX and sY then
        tap(sX, sY)
        toast("✅ Đã nhấn Story và đăng thành công!")
    else
        toast("⚠️ Không tìm thấy story.png")
    end

    toast("🏁 Hoàn tất AutoPostLatest – By Mr.L")
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP
----------------------------------------------------------------
toast("🚀 TikTok AutoLoop – Bắt đầu hoạt động...")
math.randomseed(os.time())

while true do
    toast("📡 Gọi API lấy tác vụ...")
    local resp = getAPIResponse()
    if resp then
        local opt = extractOptions(resp)
        if opt and #opt.actions > 0 then
            if hasAction(opt, "follow") then followAccounts(opt) end
            if hasAction(opt, "like") or hasAction(opt, "share") or hasAction(opt, "comment") then
                interactPosts(opt)
            end
            if hasAction(opt, "postlatest") then
                autoPostLatest(opt)
            end
        else
            toast("⏳ Không có tác vụ – nghỉ 5s")
            usleep(5000000)
        end
    else
        toast("⚠️ API lỗi – nghỉ 10s rồi thử lại")
        usleep(10000000)
    end
    usleep(8000000)
end

toast("🎉 Dừng vòng lặp – By Mr.L")
