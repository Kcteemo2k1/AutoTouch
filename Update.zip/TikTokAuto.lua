----------------------------------------------------------------
-- 🎬 TikTok AutoFlow v8.5p-FixLog5s-DeleteFlowIntegrated_v1.6-FULL
-- ✅ follow → like → share → comment → delete → download → upload → growvideo
-- 🧠 Safe Delay / Auto Kill / Stable Log / DeleteFlow Integrated / GrowVideo
-- By Mr.L
----------------------------------------------------------------

local curl = require("cURL")

----------------------------------------------------------------
-- 🪪 CONFIGURATION
----------------------------------------------------------------
local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTXJMIiwidXNlcl9pZCI6MywibGFzdF90aW1lX3B3IjowLCJpYXQiOjE3NjI3NTIxODN9.susWUV50UAO3aEparx_3sxWjAWWzV2gtaNs_ZxuVaBA"
local deviceID = "a3"
local hostName = "https://api.drxcloudphone.com"
local apiGet = hostName .. "/api/v1/tool/action/get?action_type=tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID

-- Shortcuts/Assets
local shortcutSave = "AutoSaveVideo"
local shortcutDelete = "DeletePhotos"
local imgPath = rootDir() .. "/img/"
local fixedURL = "http://file.fms-router.com:9999/data/tiktok2/2.mp4"

----------------------------------------------------------------
-- ⚙️ UTILITIES (Delay/Touch/Find/Image/OpenURL)
----------------------------------------------------------------
local function sleep5() usleep(5000000) end
local function sleep4() usleep(4000000) end
local function sleep3() usleep(3000000) end
local function delayKill() usleep(5000000) end
local function delayLog() usleep(5000000) end

local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(85000)
    touchUp(1, x, y)
    usleep(delay or 1000000)
end

local function findImgRetry(name, thr, retries)
    local threshold = thr or 0.4
    local fullPath = imgPath .. name
    retries = retries or 3
    for i = 1, retries do
        toast("🔍 Tìm ảnh: " .. name .. " (lần " .. i .. ")")
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(800000)
    end
    toast("❌ Không thấy " .. name .. " sau " .. retries .. " lần")
    return nil, nil
end

local function getBasePlus()
    -- Trả về tâm cụm nút hành động (white plus) để tính offset like/share/comment
    local x, y = findImgRetry("whiteplus.png", 0.4, 3)
    if x and y then return x, y end
    toast("⚠️ Fallback whiteplus → (381,1283)")
    return 381, 1283
end

local function openURLSafe(url)
    pcall(function()
        if type(openURL) == "function" then 
            openURL(url)
        else
            require "objc"
            local NSURL = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🌐 SERVER LOG (PUT /api/v1/tool/action/{_id})
----------------------------------------------------------------
local function sendLog(actionId, logText, statusCode)
    if not actionId then
        toast("⚠️ Thiếu _id, bỏ qua log")
        return
    end

    local apiLog = string.format("%s/api/v1/tool/action/%s?jwt=%s", hostName, actionId, jwt)
    local body = string.format('{"log":"%s","status":%d}', logText, statusCode)
    local resp = ""

    local ok, err = pcall(function()
        local c = curl.easy{
            url = apiLog,
            postfields = body,
            customrequest = "PUT",
            httpheader = {"Content-Type: application/json"},
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            timeout = 15,
            writefunction = function(s) resp = resp .. s return #s end
        }
        c:perform()
        c:close()
    end)

    if not ok then
        toast("❌ Lỗi gửi log: " .. tostring(err))
    else
        local code = resp:match('"code"%s*:%s*(%d+)') or "???"
        toast(string.format("📤 PUT Log [%d] – %s (code:%s)", statusCode, logText, code))
    end
end

----------------------------------------------------------------
-- 🛰️ API GET
----------------------------------------------------------------
local function getAPIResponse()
    local response = ""
    local c = curl.easy{
        url = apiGet,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(s) response = response .. s return #s end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

----------------------------------------------------------------
-- 🧠 PARSE RESPONSE (actions/linkAcc/linkPost/comment/scrollCount/watchDuration)
----------------------------------------------------------------
local ORDER = {"follow","like","share","comment","deletevideo","downloadvideo","postvideo","uppost","growvideo"}

local function sortActions(actions)
    table.sort(actions, function(a,b)
        local ia, ib = 999, 999
        for i,v in ipairs(ORDER) do
            if v == a then ia = i end
            if v == b then ib = i end
        end
        return ia < ib
    end)
    return actions
end

local function parseWatchDuration(raw)
    local minW, maxW = 5, 10
    if not raw or raw == "" then return minW, maxW end
    if raw:find("%-") then
        local a, b = raw:match("(%d+)%-(%d+)")
        if a and b then
            minW, maxW = tonumber(a) or 5, tonumber(b) or 10
            if minW > maxW then minW, maxW = maxW, minW end
        end
    else
        local v = tonumber(raw)
        if v then minW, maxW = v, v end
    end
    minW = math.max(1, math.floor(minW))
    maxW = math.max(minW, math.floor(maxW))
    return minW, maxW
end

local function extractOptions(resp)
    if not resp or resp == "" then return nil end

    local id = resp:match('"_id"%s*:%s*"(.-)"')
    if not id then toast("⚠️ Không tìm thấy _id trong phản hồi") return nil end

    local actions, linkAcc, linkPost, commentContent = {}, {}, {}, {}

    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do table.insert(actions, v:lower()) end
    end
    actions = sortActions(actions)

    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do
        for v in b:gmatch('"(.-)"') do table.insert(linkAcc, v) end
    end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do
        for v in c:gmatch('"(.-)"') do table.insert(linkPost, v) end
    end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do table.insert(commentContent, v) end
    end

    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5

    local scrollCountRaw = resp:match('"scrollCount"%s*:%s*"(.-)"') or resp:match('"scrollCount"%s*:%s*(%d+)')
    local scrollCount = tonumber(scrollCountRaw) or 3

    local watchDurationRaw = resp:match('"watchDuration"%s*:%s*"(.-)"') or ""
    local minWatch, maxWatch = parseWatchDuration(watchDurationRaw)

    return {
        _id = id,
        actions = actions,
        linkAcc = linkAcc,
        linkPost = linkPost,
        commentContent = commentContent,
        delay = math.max(delay, 5),
        scrollCount = math.max(1, scrollCount),
        watchDurationRaw = watchDurationRaw ~= "" and watchDurationRaw or "5-10",
        minWatch = minWatch,
        maxWatch = maxWatch
    }
end

----------------------------------------------------------------
-- 🔙 RETURN TO FEED AFTER COMMENT (theo chuỗi 3 touch bạn gửi)
----------------------------------------------------------------
local function returnToFeed()
    toast("↩️ Trở về màn hình feed...")
    touchDown(2, 441.34, 146.03); usleep(66500.54);  touchUp(2, 441.34, 146.03);  usleep(1350217.17)
    touchDown(2, 429.03, 202.03); usleep(66607.21);  touchUp(2, 429.03, 202.03);  usleep(1766896.96)
    touchDown(2, 483.43, 214.26); usleep(68080.92);  touchUp(2, 483.43, 214.26);  usleep(1200000)
end

----------------------------------------------------------------
-- 🎞️ ACTION FUNCTIONS
----------------------------------------------------------------

-- 📤 UPLOAD/POST
function autoUploadVideo()
    toast("🚀 Upload Video – Restart TikTok...")
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    openURLSafe("snssdk1233://main")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px, py)
    toast("📸 Nhấn WhitePlus")
    sleep4()

    toast("📂 Mở Library")
    touchDown(5, 91.35, 1270.06); usleep(249928.12); touchUp(5, 91.35, 1270.06); usleep(635051.00)
    tap(601, 1120); usleep(6000000)

    tap(351, 433)
    toast("🎞️ Chọn video đầu tiên")
    usleep(6000000)

    local nextX, nextY = findImgRetry("nextbutton.png", 0.4, 3)
    if nextX then
        tap(nextX, nextY)
        usleep(1500000)
        tap(nextX, nextY) -- nhấn next 2 lần như yêu cầu cũ
    else
        tap(570,1283); usleep(1500000); tap(554,1286) -- fallback tọa độ
    end
    usleep(6000000)

    local postX, postY = findImgRetry("post.png", 0.4, 3)
    if postX then tap(postX, postY) else tap(554,1286) end
    toast("✅ Đăng video hoàn tất")
    sleep4()
end

-- 💬 COMMENT (độc lập theo linkPost[1])
function autoComment(opt)
    toast("💬 Comment video...")
    if not (opt and opt.linkPost and #opt.linkPost > 0) then return end

    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()
    tap(px + 320, py - 530)  -- mở khung comment
    usleep(4000000)
    tap(px, py)              -- focus ô nhập
    usleep(3000000)

    local cmt = (#(opt.commentContent or {}) > 0 and opt.commentContent[1]) or "Nice video!"
    inputText(cmt)
    usleep(2000000)
    tap(672, 752)            -- gửi comment
    sleep4()

    -- quay lại feed để tiếp tục được các hành động sau
    returnToFeed()
end

-- ❤️ LIKE (độc lập theo linkPost[1])
function autoLike(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local px, py = getBasePlus()
    tap(px + 317, py - 660)
    sleep4()
end

-- 🔄 SHARE (độc lập theo linkPost[1])
function autoShare(opt)
    if not opt.linkPost or #opt.linkPost == 0 then return end
    openURLSafe(opt.linkPost[1])
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local px, py = getBasePlus()
    tap(px + 320, py - 257)
    sleep4()

    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()
end

-- ➕ FOLLOW (độc lập theo linkAcc[1])
function autoFollow(opt)
    if not opt.linkAcc or #opt.linkAcc == 0 then return end
    local username = opt.linkAcc[1]:match("@([%w%._%-]+)")
    if not username then return end
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    openURLSafe("snssdk1233://user/@" .. username)
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()
    local fX, fY = findImgRetry("follow_button.png", 0.4, 3)
    if fX then tap(fX, fY) else tap(550, 250) end
    sleep4()
end

----------------------------------------------------------------
-- 🆕 GROWVIDEO – Vòng nuôi = lướt 3–6 video; video cuối Like + Comment; thoát chat box
----------------------------------------------------------------
local function swipeUpOnce()
    touchDown(1, 376.68, 835.32)
    usleep(100000)
    touchMove(1, 426.98, 266.19)
    usleep(150000)
    touchUp(1, 426.98, 266.19)
    usleep(400000) -- ổn định UI nhẹ
end

function autoGrowVideo(opt)
    local loopCount = opt.scrollCount or 3
    local minW, maxW = opt.minWatch or 5, opt.maxWatch or 10
    local comments = opt.commentContent or {}

    toast("🪴 Bắt đầu nuôi kênh – " .. loopCount .. " vòng (xem " .. minW .. "-" .. maxW .. "s)")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local px, py = getBasePlus()

    for i = 1, loopCount do
        -- Số video sẽ lướt trong vòng này: 3→6 (random)
        local swipeCount = math.random(3, 6)
        toast("🎬 Vòng " .. i .. "/" .. loopCount .. " – Lướt " .. swipeCount .. " video")

        for n = 1, swipeCount do
            swipeUpOnce()
            local t = math.random(minW, maxW)
            toast("⏸️ Xem video " .. n .. " trong " .. t .. " giây...")
            usleep(t * 1000000)
        end

        -- ❤️ Like video cuối của vòng
        toast("❤️ Like video cuối (vòng " .. i .. ")")
        tap(px + 317, py - 660)
        sleep3()

        -- 💬 Comment video cuối của vòng
        local cmt = (#comments > 0 and comments[i] or comments[1]) or "Nice video!"
        toast("💬 Comment: " .. cmt)
        tap(px + 320, py - 530)  -- mở chat box
        usleep(4000000)
        tap(px, py)              -- focus ô nhập
        usleep(2000000)
        inputText(cmt)
        usleep(2000000)
        tap(672, 752)            -- gửi
        sleep4()

        -- ↩️ Thoát chat box để về feed (theo chuỗi bạn yêu cầu)
        returnToFeed()
        sleep3()

        toast("✅ Hoàn tất vòng " .. i)
        usleep(1200000)
    end

    toast("🏁 Kết thúc nuôi kênh – đã thực hiện " .. loopCount .. " vòng")
end

----------------------------------------------------------------
-- 🧩 DELETEFLOW (Shortcut: DeleteVideo → DeletePhoto → AutoSaveVideo)
----------------------------------------------------------------
local function handleDeleteConfirm()
    toast("🔍 Kiểm tra hộp thoại xác nhận...")
    local dx, dy = findImgRetry("delete1.png", 0.4, 2)
    if dx and dy then tap(dx, dy) toast("✅ Nhấn delete1.png") return end

    local ax, ay = findImgRetry("deleteall.png", 0.4, 2)
    if ax and ay then tap(ax, ay) toast("✅ Nhấn deleteall.png") return end

    local okx, oky = findImgRetry("ok.png", 0.4, 2)
    if okx and oky then tap(okx, oky) toast("⚠️ Nhấn OK") return end

    toast("🚫 Không phát hiện nút xác nhận – bỏ qua.")
end

function deleteVideo()
    toast("🧹 Bắt đầu DeleteFlow...")
    appKill("com.apple.shortcuts")
    sleep3()

    local shortcuts = {"DeleteVideo", "DeletePhoto", "AutoSaveVideo"}
    for _, name in ipairs(shortcuts) do
        local cmd = "shortcuts://run-shortcut?name=" .. name
        toast("🚀 Chạy Shortcut: " .. name)
        openURLSafe(cmd)
        sleep4()
        handleDeleteConfirm()
        sleep3()
    end

    toast("🏁 DeleteFlow hoàn tất.")
    sleep4()
end

----------------------------------------------------------------
-- ⬇️ DOWNLOAD (Shortcut AutoSaveVideo với input URL)
----------------------------------------------------------------
function downloadVideo()
    local encoded = fixedURL:gsub("([^%w])", function(c) return string.format("%%%02X", string.byte(c)) end)
    local cmd = string.format('shortcuts://run-shortcut?name=%s&inputText=%s', shortcutSave, encoded)
    openURLSafe(cmd)
    sleep4()
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow v8.5p-DeleteFlowIntegrated_v1.6 Started...")

-- (Khởi động sạch lần đầu)
delayKill()
appKill("com.ss.iphone.ugc.Ame")
sleep4()

local actionMap = {
    deletevideo = deleteVideo,
    downloadvideo = downloadVideo,
    postvideo = autoUploadVideo,
    uppost = autoUploadVideo,
    like = autoLike,
    share = autoShare,
    follow = autoFollow,
    comment = autoComment,
    growvideo = autoGrowVideo
}

while true do
    -- mỗi vòng fetch tác vụ mới
    delayKill()
    appKill("com.ss.iphone.ugc.Ame")
    sleep4()

    local resp = getAPIResponse()
    local opt = extractOptions(resp)

    if not opt or not opt._id then
        toast("⚠️ API lỗi / không có _id hợp lệ")
        sleep4()
    else
        local actionId = opt._id
        sendLog(actionId, "Start drx tiktok", 1)
        toast("🆔 _id: " .. tostring(actionId))

        if #opt.actions > 0 then
            for _, act in ipairs(opt.actions) do
                local fn = actionMap[act]
                if fn then
                    toast("▶️ Thực hiện: " .. act)
                    pcall(function() fn(opt) end)
                else
                    toast("⚙️ Bỏ qua hành động: " .. act)
                end
                usleep((opt.delay or 5) * 1000000)
            end
            delayLog()
            sendLog(actionId, "End drx tiktok", 2)
            toast("📨 Log End đã gửi xong.")
        else
            sendLog(actionId, "Fail drx tiktok (no actions)", 3)
        end
    end

    sleep5()
end

-- 🛑 never reached
