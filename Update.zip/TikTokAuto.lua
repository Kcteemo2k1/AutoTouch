----------------------------------------------------------------
-- 🎬 TikTok AutoLoop – Full Integration (Follow + Interact + AutoPostLatest Dynamic Profile)
-- By Mr.L
----------------------------------------------------------------

local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTmd1eWVuRHV5TGFtIiwidXNlcl9pZCI6OTAsImxhc3RfdGltZV9wdyI6MCwiaWF0IjoxNzYxNTE0MTMxfQ.TXOaXjnC__Iv3qIewzryrh_g92NlcR0YjVX0lpDTEek"
local deviceID = "227ce1968e1b431a"
local apiURL = "https://ibestcloud.com/api/v1/tool/action/get?action_type=Tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID
local imgPath = rootDir() .. "/img/"

----------------------------------------------------------------
-- ⚙️ TIỆN ÍCH
----------------------------------------------------------------
local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(80000)
    touchUp(1, x, y)
    usleep(delay or 500000)
end

local function openDeep(url)
    if type(openURL) == "function" then return openURL(url) end
    if type(appOpenURL) == "function" then return appOpenURL(url) end
    require "objc"
    local NSURL, UIApplication = objc.NSURL, objc.UIApplication
    return UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
end

local function findImg(name, thr)
    local r = findImage(imgPath .. name, 1, thr or 0.5, nil, false, 2)
    if r and #r > 0 then return r[1][1], r[1][2] end
    return nil, nil
end

local function waitAndTap(img, msg, thr)
    local x, y = findImg(img, thr or 0.4)
    if x and y then
        tap(x, y)
        if msg then toast(msg) end
        usleep(8000000)
        return true
    else
        toast("❌ Không tìm thấy " .. img)
        return false
    end
end

----------------------------------------------------------------
-- 🏠 RESET HOME
----------------------------------------------------------------
local function resetToHome()
    toast("🏠 Reset về trang chủ TikTok...")
    openDeep("snssdk1233://feed?refer=web")
    usleep(8000000)
end

----------------------------------------------------------------
-- 🌐 GỌI API
----------------------------------------------------------------
local function getAPIResponse()
    local curl = require("cURL")
    local response = ""
    local c = curl.easy{
        url = apiURL,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str)
            response = response .. str
            return #str
        end
    }
    local ok, err = pcall(function() c:perform() end)
    c:close()
    if not ok then
        toast("❌ API lỗi: " .. tostring(err))
        return nil
    end
    return response
end

----------------------------------------------------------------
-- 🧩 TRÍCH DỮ LIỆU TRẢ VỀ
----------------------------------------------------------------
local function extractOptions(resp)
    local actions, linkAcc, linkPost, commentList, myProfile = {}, {}, {}, {}, {}

    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do table.insert(actions, v) end
    end
    for b in resp:gmatch('"linkAcc"%s*:%s*%[(.-)%]') do
        for v in b:gmatch('"(.-)"') do table.insert(linkAcc, v) end
    end
    for c in resp:gmatch('"linkPost"%s*:%s*%[(.-)%]') do
        for v in c:gmatch('"(.-)"') do table.insert(linkPost, v) end
    end
    for d in resp:gmatch('"commentContent"%s*:%s*%[(.-)%]') do
        for v in d:gmatch('"(.-)"') do table.insert(commentList, v) end
    end
    for e in resp:gmatch('"myProfile"%s*:%s*%[(.-)%]') do
        for v in e:gmatch('"(.-)"') do table.insert(myProfile, v) end
    end

    local delay = tonumber(resp:match('"delaySec"%s*:%s*(%d+)')) or 5
    return {
        actions = actions,
        linkAcc = linkAcc,
        linkPost = linkPost,
        commentList = commentList,
        myProfile = myProfile,
        delay = delay * 1000000
    }
end

local function hasAction(opt, act)
    for _, a in ipairs(opt.actions or {}) do
        if a == act then return true end
    end
    return false
end

local function randomComment(opt)
    local list = opt.commentList or {}
    if #list == 0 then return nil end
    return list[math.random(1, #list)]
end

----------------------------------------------------------------
-- 🔘 AUTO FOLLOW
----------------------------------------------------------------
local function followIfNeeded()
    usleep(80000)
    local p = findImg("follow_button.png", 0.6)
    if p then
        tap(p[1], p[2])
        toast("✅ Đã nhấn Follow")
        usleep(3000000)
    else
        toast("⚠️ Không thấy nút Follow")
        usleep(2000000)
    end
end

local function followAccounts(opt)
    resetToHome()
    for i, acc in ipairs(opt.linkAcc or {}) do
        if acc ~= "" then
            local username = acc:match("@([%w%._%-]+)")
            if username then
                local link = "snssdk1233://user/@" .. username
                toast("🔗 (" .. i .. ") @" .. username)
                openDeep(link)
                usleep(6000000)
                followIfNeeded()
                usleep(3000000)
            end
        end
    end
end

----------------------------------------------------------------
-- 💬 AUTO INTERACT POST
----------------------------------------------------------------
local function interactPosts(opt)
    resetToHome()
    for _, post in ipairs(opt.linkPost or {}) do
        local awemeID = post:match("/video/(%d+)")
        local deep = awemeID and ("snssdk1233://aweme/detail/" .. awemeID) or post
        toast("🎬 Mở bài: " .. post)
        openDeep(deep)
        usleep(7000000)
        appActivate("com.ss.iphone.ugc.Ame")

        touchDown(4, 688.71, 551.26); usleep(83259.46); touchUp(4, 688.71, 551.26); usleep(1534928.58);
        touchDown(3, 690.77, 949.35); usleep(83393.79); touchUp(3, 690.77, 949.35); usleep(1832034.67);
        touchDown(6, 108.79, 1006.36); usleep(101348.17); touchUp(6, 108.79, 1006.36); usleep(4482539.00);
        touchDown(1, 684.61, 684.63); usleep(67895.96); touchUp(1, 684.61, 684.63); usleep(1848500.00);
        touchDown(2, 355.13, 1275.15); usleep(101478.38); touchUp(2, 355.13, 1275.15);

        local cmt = randomComment(opt)
        if cmt then
            usleep(1000000)
            inputText(cmt)
            usleep(1000000)
            touchDown(2, 671.26, 779.32)
            usleep(65136.83)
            touchUp(2, 671.26, 779.32)
            toast("💬 Comment: " .. cmt)
        else
            toast("⚠️ Không có comment trong danh sách")
        end
        usleep(opt.delay or 5000000)
    end
end

----------------------------------------------------------------
-- 🧩 AUTO POST LATEST (có nghỉ ngẫu nhiên 1–2s)
----------------------------------------------------------------
local function autoPostLatest(opt)
    resetToHome()
    toast("🚀 Bắt đầu AutoPost – Đăng Story mới nhất...")

    local profileURL = (opt.myProfile and #opt.myProfile > 0) and opt.myProfile[1] or "https://www.tiktok.com/@mr_zerro3"
    toast("👤 Mở trang cá nhân: " .. profileURL)
    openDeep(profileURL)
    usleep(8000000)

    toast("🔍 Tìm EditButton...")
    local editX, editY = findImg("editbutton.png", 0.5)

    if editX and editY then
        toast(string.format("✅ EditButton tại (%.2f, %.2f)", editX, editY))
        local plusX = editX - 83.14
        local plusY = editY - 83.48
        touchDown(6, plusX, plusY)
        usleep(98478.38)
        touchUp(6, plusX, plusY)
        toast("➕ Đã nhấn nút Plus trên avatar")
    else
        toast("❌ Không tìm thấy EditButton")
        return
    end

    -- Nghỉ ngẫu nhiên 1–2 giây trước khi tìm AllButton
    usleep(math.random(1000000, 2000000))

    toast("🔍 Tìm AllButton...")
    local allX, allY = findImg("allbutton.png", 0.5)

    if allX and allY then
        toast(string.format("✅ AllButton tại (%.2f, %.2f)", allX, allY))
        local photo1X = allX + (121.11 - allX)
        local photo1Y = allY + (495.26 - allY)
        local photo2X = allX + (127.27 - allX)
        local photo2Y = allY + (647.97 - allY)

        touchDown(5, photo1X, photo1Y)
        usleep(84450.29)
        touchUp(5, photo1X, photo1Y)
        usleep(600195.92)

        touchDown(2, photo2X, photo2Y)
        usleep(48569.79)
        touchUp(2, photo2X, photo2Y)
        usleep(1500000)

        -- Nghỉ ngẫu nhiên 1–2 giây trước khi tìm Story
        usleep(math.random(1000000, 2000000))

        toast("📸 Tìm nút Story...")
        local sX, sY = findImg("story.png", 0.5)
        if sX and sY then
            tap(sX, sY)
            toast("✅ Đã nhấn Story!")
        else
            toast("⚠️ Không tìm thấy Story.png")
        end
    else
        toast("❌ Không tìm thấy AllButton")
    end

    toast("🏁 Hoàn tất AutoPostLatest – By Mr.L")
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP
----------------------------------------------------------------
toast("🚀 TikTok AutoLoop – Bắt đầu hoạt động...")
math.randomseed(os.time())

while true do
    toast("📡 Gọi API lấy tác vụ...")
    local resp = getAPIResponse()
    if resp then
        local opt = extractOptions(resp)
        if opt and #opt.actions > 0 then
            if hasAction(opt, "follow") then followAccounts(opt) end
            if hasAction(opt, "like") or hasAction(opt, "share") or hasAction(opt, "comment") then
                interactPosts(opt)
            end
            if hasAction(opt, "postlatest") then
                autoPostLatest(opt)
            end
        else
            toast("⏳ Không có tác vụ – nghỉ 5s")
            usleep(5000000)
        end
    else
        toast("⚠️ API lỗi – nghỉ 10s rồi thử lại")
        usleep(10000000)
    end
    usleep(8000000)
end

toast("🎉 Dừng vòng lặp – By Mr.L")
