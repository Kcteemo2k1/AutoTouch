----------------------------------------------------------------
-- 🎬 TikTok AutoFlow – Delete → Download → Upload + Others
-- ✅ Version v8.1 – Logical Order Fix + Stable API Integration
-- By Mr.L
----------------------------------------------------------------

----------------------------------------------------------------
-- ⚙️ CONFIGURATION
----------------------------------------------------------------
local jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJ2dWFnYTJrMSIsImxldmVsIjo5OSwiZnVsbF9uYW1lIjoiTmd1eWVuRHV5TGFtIiwidXNlcl9pZCI6OTAsImxhc3RfdGltZV9wdyI6MCwiaWF0IjoxNzYxNTE0MTMxfQ.TXOaXjnC__Iv3qIewzryrh_g92NlcR0YjVX0lpDTEek"
local deviceID = "227ce1968e1b431a"
local apiURL = "https://ibestcloud.com/api/v1/tool/action/get?action_type=Tiktok&jwt=" .. jwt .. "&device_id=" .. deviceID
local shortcutSave = "AutoSaveVideo"
local shortcutDelete = "Delete Photos"
local fixedURL = "http://file.fms-router.com:9999/data/tiktok2/2.mp4"
local imgPath = rootDir() .. "/img/"

----------------------------------------------------------------
-- 🧩 UTILITIES
----------------------------------------------------------------
local function sleep4() usleep(4000000) end
local function toastAuto(msg, sec)
    toast(msg)
    usleep((sec or 2) * 1000000)
    toast("")
end

local function encodeURL(str)
    return (string.gsub(str, "([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end

local function tap(x, y, delay)
    if not x or not y then return end
    touchDown(1, x, y)
    usleep(85000)
    touchUp(1, x, y)
    usleep(delay or 4000000)
end

local function findImg(name, thr)
    local threshold = thr or 0.4
    local fullPath = imgPath .. name
    toast("🔍 Tìm ảnh: " .. name)
    for i = 1, 3 do
        local r = findImage(fullPath, 1, threshold, nil, false, 2)
        if r and #r > 0 then
            local x, y = r[1][1], r[1][2]
            toast("✅ " .. name .. " tại [" .. math.floor(x) .. "," .. math.floor(y) .. "]")
            return x, y
        end
        usleep(1000000)
    end
    toast("❌ Không thấy " .. name)
    return nil, nil
end

local function openURLSafe(url)
    toast("🌐 Mở URL: " .. url)
    pcall(function()
        if type(openURL) == "function" then openURL(url)
        else
            require "objc"
            local NSURL = objc.NSURL
            local UIApplication = objc.UIApplication
            UIApplication:sharedApplication():openURL_(NSURL:URLWithString_(url))
        end
    end)
    sleep4()
end

----------------------------------------------------------------
-- 🗑️ HÀM 1 – XOÁ VIDEO
----------------------------------------------------------------
function deleteVideo()
    local cmd = string.format('shortcuts://run-shortcut?name=%s', shortcutDelete)
    toastAuto("🗑️ Gọi Shortcut Delete để xoá video cũ...", 2)
    if type(appOpenURL) == "function" then appOpenURL(cmd)
    else openURL(cmd) end
    toastAuto("✅ Đã gửi lệnh xoá video!", 4)
end

----------------------------------------------------------------
-- 📥 HÀM 2 – TẢI VIDEO MỚI
----------------------------------------------------------------
function downloadVideo()
    local encoded = encodeURL(fixedURL)
    local cmd = string.format('shortcuts://run-shortcut?name=%s&inputText=%s', shortcutSave, encoded)
    toastAuto("📲 Gọi AutoSaveVideo để tải file...", 2)
    if type(appOpenURL) == "function" then appOpenURL(cmd)
    else openURL(cmd) end
    toastAuto("⏳ Đợi quá trình tải hoàn tất...", 8)
end

----------------------------------------------------------------
-- 📤 HÀM 3 – UPLOAD VIDEO LÊN TIKTOK
----------------------------------------------------------------
function autoUploadVideo()
    toast("🚀 Bắt đầu Upload Video – Clean Restart")
    sleep4()

    toast("🛑 Đang tắt TikTok...")
    appKill("com.ss.iphone.ugc.Ame")
    usleep(1500000)
    toast("✅ TikTok đã được đóng.")

    keyDown(KEY_TYPE.HOME_BUTTON); usleep(200000); keyUp(KEY_TYPE.HOME_BUTTON); sleep4()

    openURLSafe("snssdk1233://main")
    appActivate("com.ss.iphone.ugc.Ame")
    sleep4()

    local x, y = findImg("whiteplus.png", 0.35)
    if not x then toast("⚠️ Không thấy whiteplus.png – dừng."); return end
    tap(x, y); sleep4()

    local libX, libY = 601.47, 1120.39
    toast("🎞️ Mở Thư viện..."); touchDown(6, libX, libY); usleep(66774.88); touchUp(6, libX, libY); sleep4()

    local allX, allY = findImg("whiteallbutton.png", 0.4)
    if allX then tap(allX, allY + 100); sleep4(); tap(allX, allY + 200); sleep4()
    else toast("⚠️ Không thấy whiteallbutton.png") end

    local nextX, nextY = findImg("nextbutton.png", 0.4)
    if nextX and nextY then tap(nextX, nextY); sleep4(); tap(nextX, nextY); sleep4()
    else toast("❌ Không thấy nextbutton.png – dừng upload."); return end

    local postX, postY = findImg("post.png", 0.4)
    if postX then tap(postX, postY); toast("✅ Upload hoàn tất.") else toast("⚠️ Không thấy post.png") end
    sleep4()
end

----------------------------------------------------------------
-- 🌐 HÀM 4 – GỌI API
----------------------------------------------------------------
local function getAPIResponse()
    local curl = require("cURL")
    local response = ""
    local c = curl.easy{
        url = apiURL,
        ssl_verifypeer = false,
        ssl_verifyhost = false,
        writefunction = function(str) response = response .. str return #str end
    }
    pcall(function() c:perform() end)
    c:close()
    return response
end

local function extractActions(resp)
    local actions = {}
    for a in resp:gmatch('"actions"%s*:%s*%[(.-)%]') do
        for v in a:gmatch('"(.-)"') do
            table.insert(actions, v:lower())
        end
    end
    return actions
end

----------------------------------------------------------------
-- 🔁 MAIN LOOP – LUÔN XÓA TRƯỚC ➜ TẢI ➜ CÁC HÀNH ĐỘNG
----------------------------------------------------------------
toast("🚀 TikTok AutoFlow v8.1 – Delete→Download→Upload flow khởi chạy...")
math.randomseed(os.time())

while true do
    toast("📡 Gọi API lấy tác vụ...")
    local resp = getAPIResponse()

    if resp and resp ~= "" then
        local actions = extractActions(resp)

        -- 🔁 Đặt lại thứ tự hành động
        local ordered = {}
        local order = {"deletevideo", "downloadvideo", "postvideo", "uppost", "like", "share", "comment", "follow"}
        for _, name in ipairs(order) do
            for _, act in ipairs(actions) do
                if act == name then table.insert(ordered, act) end
            end
        end

        if #ordered == 0 then
            toast("⏳ Không có hành động – nghỉ 5s...")
            sleep4()
        else
            for _, act in ipairs(ordered) do
                if act == "deletevideo" then
                    deleteVideo()
                elseif act == "downloadvideo" then
                    downloadVideo()
                elseif act == "postvideo" or act == "uppost" then
                    autoUploadVideo()
                else
                    toast("⚙️ Bỏ qua hành động phụ: " .. act)
                end
                sleep4()
            end
        end
    else
        toast("⚠️ API lỗi hoặc không phản hồi – nghỉ 5s...")
    end

    sleep4()
end

toast("🛑 Dừng vòng lặp – By Mr.L")
